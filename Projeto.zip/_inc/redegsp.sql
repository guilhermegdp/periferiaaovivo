CREATE DATABASE redegsp CHARACTER SET latin1 COLLATE latin1_bin;
USE redegsp;

create table tb_clientes(
	codigo int(5)primary key auto_increment,
    cliente VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    logradouro VARCHAR(100) NOT NULL,
    numero INT(5) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    uf VARCHAR(2) NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    celular VARCHAR(15) NOT NULL,
    INDEX (cliente)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;


INSERT INTO `tb_clientes` (`codigo`,`cliente`, `email`, `cep`, `logradouro`, `numero`, `bairro`, `cidade`, `uf`, `telefone`, `celular`) VALUES
(1, 'Guilherme Dias Pereira', 'gdp@0412.com', '08574-432', 'Rua Curitiba', 40, 'JD. mirai', 'Itaqua', 'SP', '11 946470415', '1146470415'),
(2, 'Dias', 'gdp@0412.com', '08574-432', 'Rua Curitiba', 40, 'JD. mirai', 'Itaqua', 'SP', '11 946470415', '1146470415');


select * from tb_clientes;
CREATE TABLE tb_produtos(
	codigoprd INT(5)PRIMARY KEY AUTO_INCREMENT,
    produto VARCHAR(100)NOT NULL,
    marca VARCHAR(100)NOT NULL,
    preco varchar(10) NOT NULL,
    INDEX (produto)
)ENGINE=MyISAM CHARACTER SET latin1 COLLATE latin1_bin;
/*preco DECIMAL(10,2) NOT NULL,*/;
insert into tb_produtos(produto,marca,preco)values('PLaca mae','Giga',100.91),('placa usb','teste',50.00);
select * from tb_produtos;
CREATE TABLE tb_ordens(
	data_os datetime not null,
    codigoclt int(5),
    cliente VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    logradouro VARCHAR(100) NOT NULL,
    numero INT(5) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    uf VARCHAR(2) NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    celular VARCHAR(15) NOT NULL,
    codigoprd INT(5),
    produto VARCHAR(100)NOT NULL,
    marca VARCHAR(100)NOT NULL,
    preco varchar(10) NOT NULL    
)ENGINE=MyISAM CHARACTER SET latin1 COLLATE latin1_bin;
select * from tb_ordens;


drop database redegsp