<?php
		include('conexao.php');
		
		if(isset($_POST['btn_ordens'])){
			$data=$_POST['data_os'];
			$nova_data = implode("-", array_reverse(explode("/", $data)));
			$codigo=$_POST['codigoclt'];
			$nome=$_POST['cliente'];
			$email=$_POST['email'];
			$cep=$_POST['cep'];
			$logradouro=$_POST['logradouro'];
			$numero=$_POST['numero'];
			$bairro=$_POST['bairro'];
			$cidade=$_POST['cidade'];
			$uf= $_POST['uf'];
			$telefone=$_POST['telefone'];
			$celular=$_POST['celular'];
			$codigoprd=$_POST['codigoprd'];
			$produto=$_POST['produto'];
			$marca=$_POST['marca'];
			$preco=$_POST['preco'];
			
		}
			$inserir="INSERT INTO tb_ordens(data_os,codigoclt,cliente,email,cep,logradouro,numero,bairro,cidade,uf,telefone,celular,codigoprd,produto,marca,preco)
			VALUES('".$nova_data."','".$codigo."','".$nome."','".$email."','".$cep."','".$logradouro."','".$numero."','".$bairro."','".$cidade."','".$uf."','".$telefone."','".$celular."','".$codigoprd."','".$produto."','".$marca."','".$preco."')";
			
		if ($conn->query($inserir)) {
			
			header('Location:../index.php');
		} else {
			echo ("Error: " . $inserir . "<br>" . mysqli_error($conn));
		}
		

?>