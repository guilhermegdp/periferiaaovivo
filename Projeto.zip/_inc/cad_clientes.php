<?php
		include('conexao.php');
		
		if(isset($_POST['btn_clientes'])){
			$nome=ucwords($_POST['inp_nome']);
			$email=$_POST['inp_email'];
			$cep=$_POST['inp_cep'];
			$logradouro=ucfirst($_POST['inp_logradouro']);
			$numero=$_POST['inp_numero'];
			$bairro=ucfirst($_POST['inp_bairro']);
			$cidade=ucfirst($_POST['inp_cidade']);
			$uf= strtoupper($_POST['inp_uf']);
			$telefone=$_POST['inp_telefone'];
			$celular=$_POST['inp_celular'];
			
		}
			$inserir="INSERT INTO tb_clientes (cliente,email,cep,logradouro,numero,bairro,cidade,uf,telefone,celular)
			VALUES('".$nome."','".$email."','".$cep."','".$logradouro."','".$numero."','".$bairro."','".$cidade."','".$uf."','".$telefone."','".$celular."')";
			
		if ($conn->query($inserir)) {
			//echo('<script>alert("Cadastrado com Sucesso!<br>Você sera redirecionado";)</script>');
			header('Location:../index.php');
		} else {
			echo ("Error: " . $inserir . "<br>" . mysqli_error($conn));
		}
		

		?>