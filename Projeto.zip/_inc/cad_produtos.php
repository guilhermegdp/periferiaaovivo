<?php
	include('conexao.php');
		
	if(isset($_POST['btn_produtos'])){
		$produto=$_POST['inp_produto'];
		$marca=$_POST['inp_marca'];
		$preco=$_POST['inp_preco'];
	}
		$inserir="INSERT INTO tb_produtos(produto,marca,preco)VALUES('".$produto."','".$marca."','".$preco."')";
	if (mysqli_query($conn, $inserir)) {
			//echo('<script>alert("Cadastrado com Sucesso!<br>Você sera redirecionado";)</script>');
			header('Location:../index.php');
	} else {
		echo ("Error: " . $inserir . "<br>" . mysqli_error($conn));
		}
	
?>